import os
import requests
from colorama import init, Fore

# تفعيل الألوان في الكونسول
init(autoreset=True)

def show_banner():
    os.system("cls" if os.name == "nt" else "clear")
    banner = Fore.BLUE + r"""
   _____  ____   _____ 
  / ____|/ __ \ / ____|
 | (___ | |  | | |     
  \___ \| |  | | |     
  ____) | |__| | |____ 
 |_____/ \____/ \_____|
      S   O   C

=========================================
         Threat Intelligence        
                                
=========================================

🔍 Starting ViperScan... Analyzing IPs...
----------------------------------------
"""
    print(banner)

def is_vpn_or_proxy(data):
    tags = data.get("attributes", {}).get("tags", [])
    for tag in tags:
        if "vpn" in tag.lower() or "proxy" in tag.lower():
            return True
    return False

def check_ip(ip, api_key):
    url = f"https://www.virustotal.com/api/v3/ip_addresses/{ip}"
    headers = {
        "x-apikey": api_key
    }
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json().get("data", {})
        
        last_analysis_stats = data.get("attributes", {}).get("last_analysis_stats", {})
        malicious = last_analysis_stats.get("malicious", 0)
        suspicious = last_analysis_stats.get("suspicious", 0)
        total_threats = malicious + suspicious
        
        vpn_proxy = is_vpn_or_proxy(data)

        if vpn_proxy:
            status = "Suspicious (VPN/Proxy) 🌐"
        elif total_threats > 0:
            status = "Malicious⚠️"
        else:
            status = "Clean ✅"

        return {
            "ip": ip,
            "status": status,
            "threats": total_threats,
            "vpn": vpn_proxy
        }
    else:
        return {
            "ip": ip,
            "status": f"Error ❌ ({response.status_code})",
            "threats": "N/A",
            "vpn": False
        }

def read_ips_from_file(file_path):
    with open(file_path, "r") as file:
        ip_list = file.readlines()
    ip_list = [ip.strip() for ip in ip_list]
    return ip_list

def main():
    show_banner()
    api_key = "9cfa1ecab36b307faa117a97cbf9832123508c3f49427b81cd5c221b0e71824a"
    file_path = "C:\\Users\\edriss\\Downloads\\virus total\\IP_list.txt"

    ip_list = read_ips_from_file(file_path)

    print("🔍 Checking IP addresses...")
    suspicious_ips = []
    for ip in ip_list:
        result = check_ip(ip, api_key)
        print(f"📍 IP: {result['ip']}")
        print(f"🔎 Status: {result['status']}")
        print(f"🛡️ Threats: {result['threats']}")
        print(f"🌐 VPN/Proxy: {'✅ Yes' if result['vpn'] else '❌ No'}")
        print("-" * 30)

        if result['vpn'] or result['status'] == "Malicious ⚠️":
            suspicious_ips.append(result['ip'])
    
    print("\n🌐 Suspicious/Malicious IPs (VPN or Malicious):")
    for ip in suspicious_ips:
        print(f"📍 {ip}")

if __name__ == "__main__":
    main()
